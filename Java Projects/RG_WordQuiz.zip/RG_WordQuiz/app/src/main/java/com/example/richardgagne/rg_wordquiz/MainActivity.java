package com.example.richardgagne.rg_wordquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.slider.Slider;

public class MainActivity extends AppCompatActivity {
    Switch grassSwitch;
    Switch groundSwitch;
    Switch ghostSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        grassSwitch = findViewById(R.id.grassType);
        groundSwitch = findViewById(R.id.groundType);
        ghostSwitch = findViewById(R.id.ghostType);
    }

    public void checkAnswer(View view)
    {
        if(grassSwitch.isChecked() == true && groundSwitch.isChecked() == true && ghostSwitch.isChecked() == true){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == true && groundSwitch.isChecked() == false && ghostSwitch.isChecked() == false){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == false && groundSwitch.isChecked() == true && ghostSwitch.isChecked() == false){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == false && groundSwitch.isChecked() == false && ghostSwitch.isChecked() == false){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == true && groundSwitch.isChecked() == true && ghostSwitch.isChecked() == false){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == false && groundSwitch.isChecked() == true && ghostSwitch.isChecked() == true){
            Toast.makeText(getApplicationContext(), "Wrong Answer!", Toast.LENGTH_LONG).show();
        } else if(grassSwitch.isChecked() == false && groundSwitch.isChecked() == false && ghostSwitch.isChecked() == true){
            Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_LONG).show();
        };




    }

}