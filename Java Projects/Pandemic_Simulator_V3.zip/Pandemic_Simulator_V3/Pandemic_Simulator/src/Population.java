
/**
 * Author: Kareem Idris, Student#: 0881393 Section:, Geraldine Lopez Student#: 0876012 Section: 2, Richard Gagne Student#: 0979551 Section: 4, Matt Daly Student#: 1022438 Section 4
 * Program: Population.java
 * Purpose: Creates the population which is updated ever 250 cycles.
 * Date: Aug 10, 2022
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Population extends JPanel {
	
	private final int WIDTH = 435, HEIGHT = 435;// size of JPanel
	private final int LAG_TIME = 125; // 250 time in milliseconds between re-paints of screen
	private Timer time;// Timer class object that will fire events every LAG_TIME interval
	private final int IMG_DIM = 10; // size of Person to be drawn

	enum ImmunityStatus {
		NONE,
		MILD,
		MODERATE,
		GOOD,
		NATURAL
	}

	public ImmunityStatus immunityStatus;
	int numImmune = 0;
	int numNImmune = 0;
	int numOneShot = 0;
	int numTwoShot = 0;
	int numThreeShot = 0;
	int numPopulation = 0;
	int numDied = 0;
	int numRecovered = 0;
	int numInfected = 1;
	Person person = new Person();
	boolean isAlive = true;
	boolean isInfected = false;
	boolean hasRecovered = false;
	int max = 100;
	int min = 0;
	int random_int;
	
	private Person[] PersonArray;

	//-----------------\\
	//   Time Setter   \\
	//-----------------\\

	/*
	 * Function: TimeSetter()
	 * Purpose: Sets the time for the timer to fire every 250 milliseconds.
	 * Parameters: None
	 * Return: None
	 */
	public void TimeSetter(int lagTime) {
		this.time = new Timer(lagTime, new BounceListener());
	}

	//------------------\\
	//   Time Stopper   \\
	//------------------\\

	/*
	 * Function: TimeStopper()
	 * Purpose: Stops the timer from firing events.
	 * Parameters: None
	 * Return: None
	 */
	 
	public void TimeStopper() {
		this.time.stop();
	}

	//-----------------\\
	//   Time Resume   \\
	//-----------------\\

	/*
	 * Function: TimeResume()
	 * Purpose: Resumes the timer from firing events.
	 * Parameters: None
	 * Return: None
	 */
	 
	public void TimeResume() {
		this.time.start();
	}

	//------------------\\
	//   Death Timers   \\
	//------------------\\

	/*
	 * Function: DeathTimers()
	 * Purpose: Sets the timer for the person to die.
	 * Parameters: None
	 * Return: None
	 */
	private final int recoveryTime = 150;
	ActionListener killPerson = new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			random_int = (int) (Math.random() * (max - min + 1) + min);
			Person.ImmunityStatus personStatus = person.getStatus();
			if (personStatus.NONE == Person.ImmunityStatus.NONE && person.isInfected == true && random_int <= 10) {
				// No Immunity
				person.setxIncrement(0);
				person.setyIncrement(0);
				person.setColor(Color.BLACK);
				person.isAlive = false;
				person.hasDied = true;
				numDied++;
			} else if (personStatus.MILD == Person.ImmunityStatus.MILD && person.isInfected == true
					&& random_int <= 7) {
				// One Shot
				person.setxIncrement(0);
				person.setyIncrement(0);
				person.setColor(Color.BLACK);
				person.isAlive = false;
				person.hasDied = true;
				numDied++;
			} else if (personStatus.MODERATE == Person.ImmunityStatus.MODERATE && person.isInfected == true
					&& random_int <= 3) {
				// Two Shots
				person.setxIncrement(0);
				person.setyIncrement(0);
				person.setColor(Color.BLACK);
				person.isAlive = false;
				person.hasDied = true;
				numDied++;
			} else if (personStatus.GOOD == Person.ImmunityStatus.GOOD && person.isInfected == true
					&& random_int <= 3) {
				// Three Shots
				person.setxIncrement(0);
				person.setyIncrement(0);
				person.setColor(Color.BLACK);
				person.isAlive = false;
				person.hasDied = true;
				numDied++;
			} else if (personStatus.NATURAL == Person.ImmunityStatus.NATURAL && person.isInfected == true
					&& random_int <= 1) {
				// Natural Immunity (Recovered once before)
				person.setxIncrement(0);
				person.setyIncrement(0);
				person.setxCoord(0);
				person.setyCoord(0);
				person.setColor(Color.BLACK);

				person.isAlive = false;
				person.hasDied = true;
				numDied++;
			} else if (person.isInfected == true && person.hasRecovered == false) {

				// Recovered
				person.hasRecovered = true;
				person.isInfected = false;
				person.setColor(Color.GREEN);
				person.setImmunityStatus(personStatus.NATURAL);
				numRecovered++;
			}
			person = new Person();
		}
	};

	Timer infectionTimer;

	//================\\
	//   POPULATION   \\
	//================\\

	/*
	 * Function: Population()
	 * Purpose: Constructor for the Population class.
	 * Parameters: None
	 * Return: None
	 */
	public Population(int population, int imm, int nImm, int one, int two, int three) {
		
		PersonArray = new Person[population];
		this.setPopulation(population);
		TimeSetter(LAG_TIME);

		numImmune = imm;
		numNImmune = nImm;
		numOneShot = one;
		numTwoShot = two;
		numThreeShot = three;

		//------------------\\
		//   Patient Zero   \\
		//------------------\\

		PersonArray[0] = new Person(IMG_DIM, Color.RED, WIDTH, HEIGHT, Person.ImmunityStatus.NONE);

		// no immunity = BLUE (10% chance of death)
		// one shot = CYAN (7% chance of death)
		// two shot = YELLOW (3% chance of death)
		// three shot = MAGENTA (1% chance of death)
		// infected = RED
		// recovered = GREEN
		// dead = BLACK

		int i, count = 1, max = PersonArray.length;

		if (count < max) {
			for (i = 0; i < numImmune; i++) {
				PersonArray[count] = new Person(IMG_DIM, Color.GREEN, WIDTH, HEIGHT, Person.ImmunityStatus.NATURAL);
				count++;
			}
		}
		if (count < max) {
			for (i = 0; i < numNImmune; i++) {
				PersonArray[count] = new Person(IMG_DIM, Color.BLUE, WIDTH, HEIGHT, Person.ImmunityStatus.NONE);
				count++;
			}
		}
		if (count < max) {
			for (i = 0; i < numOneShot; i++) {
				PersonArray[count] = new Person(IMG_DIM, Color.CYAN, WIDTH, HEIGHT, Person.ImmunityStatus.MILD);
				count++;
			}
		}
		if (count < max) {
			for (i = 0; i < numTwoShot; i++) {
				PersonArray[count] = new Person(IMG_DIM, Color.YELLOW, WIDTH, HEIGHT, Person.ImmunityStatus.MODERATE);
				count++;
			}
		}
		if (count < max) {
			for (i = 0; i < numThreeShot; i++) {
				PersonArray[count] = new Person(IMG_DIM, Color.MAGENTA, WIDTH, HEIGHT, Person.ImmunityStatus.GOOD);
				count++;
			}
		}
		if (count == 1 || count != max) {
			while (count < max) {
				PersonArray[count] = new Person(IMG_DIM, Color.BLUE, WIDTH, HEIGHT, Person.ImmunityStatus.NONE);
				count++;
			}
		}
		
		this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.setBackground(Color.WHITE);

		this.time.start();

	}// end constructor

	//-------------------------------\\
	//   Getter and Setter Variables \\
	//-------------------------------\\

	/*
	 * Function: setImmune()
	 * Purpose: Set the number of immune people in the population.
	 * Parameters: int immune
	 * Return: None
	 */
	 
	void setImmune(int numImmune) {
		this.numImmune = numImmune;
	}

	/*
	 * Function: setNImmune()
	 * Purpose: Set the number of non-immune people in the population.
	 * Parameters: int nImmune
	 * Return: None
	 */
	void setNImmune(int numNImmune) {
		this.numNImmune = numNImmune;
	}

	/*
	 * Function: setOneShot()
	 * Purpose: Set the number of one-shot people in the population.
	 * Parameters: int oneShot
	 * Return: None
	 */

	void setOneShot(int numOneShot) {
		this.numOneShot = numOneShot;
	}

	/*
	 * Function: setTwoShot()
	 * Purpose: Set the number of two-shot people in the population.
	 * Parameters: int twoShot
	 * Return: None
	 */

	void setTwoShot(int numTwoShot) {
		this.numTwoShot = numTwoShot;
	}

	/*
	 * Function: setThreeShot()
	 * Purpose: Set the number of three-shot people in the population.
	 * Parameters: int threeShot
	 * Return: None
	 */

	void setThreeShot(int numThreeShot) {
		this.numThreeShot = numThreeShot;
	}

	/*
	 * Function: setPopulation()
	 * Purpose: Set the number of people in the population.
	 * Parameters: int population
	 * Return: None
	 */
	void setPopulation(int numPopulation) {
		this.numPopulation = numPopulation;
	}

	/*
	 * Function: getImmune()
	 * Purpose: Get the number of immune people in the population.
	 * Parameters: None
	 * Return: int immune
	 */

	int getImmune() {
		return numImmune;
	}

	/*
	 * Function: getNImmune()
	 * Purpose: Get the number of non-immune people in the population.
	 * Parameters: None
	 * Return: int nImmune
	 */

	int getNImmune() {
		return numNImmune;
	}

	/*
	 * Function: getOneShot()
	 * Purpose: Get the number of one-shot people in the population.
	 * Parameters: None
	 * Return: int oneShot
	 */

	int getOneShot() {
		return numOneShot;
	}

	/*
	 * Function: getTwoShot()
	 * Purpose: Get the number of two-shot people in the population.
	 * Parameters: None
	 * Return: int twoShot
	 */

	int getTwoShot() {
		return numTwoShot;
	}

	/*
	 * Function: getThreeShot()
	 * Purpose: Get the number of three-shot people in the population.
	 * Parameters: None
	 * Return: int threeShot
	 */

	int getThreeShot() {
		return numThreeShot;
	}

	/*
	 * Function: getPopulation()
	 * Purpose: Get the number of people in the population.
	 * Parameters: None
	 * Return: int population
	 */
	
	int getPopulation() {
		return numPopulation;
	}

	/*
	 * Function: getNumDied()
	 * Purpose: Get the number of people that have died.
	 * Parameters: None
	 * Return: int numDied
	 */
	 
	String getNumDied() {
		return Integer.toString(numDied);
	}

	/*
	 * Function: getNumRecovered()
	 * Purpose: Get the number of people that have recovered.
	 * Parameters: None
	 * Return: int numRecovered
	 */
	 
	String getNumRecovered() {
		return Integer.toString(numRecovered);
	}

	/*
	 * Function: getNumInfected()
	 * Purpose: Get the number of people that are infected.
	 * Parameters: None
	 * Return: int numInfected
	 */

	String getNumInfected() {
		return Integer.toString(numInfected);
	}

	//---------------------\\
	//   Paint Component   \\
	//---------------------\\

	
	/*
	 * Function: paintComponent()
	 * Purpose: Paint the component.
	 * Parameters: Graphics g
	 * Return: None
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		// set brush color
		g.setColor(Color.PINK);
		
		for (int i = 0; i < PersonArray.length; i++) {
			// get the color

			// SET THE COLOR OF THE PERSON BASED ON THE PERCENTILE OF THE SLIDERS
			g.setColor(PersonArray[i].getColor());
			g.fillOval(PersonArray[i].getxCoord(), PersonArray[i].getyCoord(), PersonArray[i].getDiameter(),
					PersonArray[i].getDiameter());
		}
		// draw a circle shape

	}// end paintComponent over-ride

	

	//---------------------\\
	//   Bounce Listener   \\
	//---------------------\\

	/*
	 * Function: BounceListener()
	 * Purpose: Constructor for the bounce listener.
	 * Parameters: None
	 * Return: None
	 */
	 
	private class BounceListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			for (int i = 0; i < PersonArray.length; i++) {
				calcPosition(PersonArray[i]);
			}

			int deltaX;// difference in pixels of the x coordinates of the two Persons being compared.
			int deltaY;// difference in pixels of the y coordinates of the two Persons being compared.

			int firstPersonX, firstPersonY, secondPersonX, secondPersonY;

			
			for (int i = 0; i < PersonArray.length - 1; i++)
			{
				firstPersonX = PersonArray[i].getxCoord();
				firstPersonY = PersonArray[i].getyCoord();

				if (PersonArray[i].hasDied)
					continue;

				for (int j = i + 1; j < PersonArray.length; j++) {
					secondPersonX = PersonArray[j].getxCoord();
					secondPersonY = PersonArray[j].getyCoord();

					if (PersonArray[i].hasDied)
						continue;

					// now calculate deltaX and deltaY for the pair of Persons
					deltaX = firstPersonX - secondPersonX;
					deltaY = firstPersonY - secondPersonY;

					if (Math.sqrt(deltaX * deltaX + deltaY * deltaY) <= IMG_DIM)// if true, they have touched
					{
						// FirstPerson
						PersonArray[i].setxIncrement(PersonArray[i].getxIncrement() * -1);
						PersonArray[i].setyIncrement(PersonArray[i].getyIncrement() * -1);

						// SecondPerson
						PersonArray[j].setxIncrement(PersonArray[j].getxIncrement() * -1);
						PersonArray[j].setyIncrement(PersonArray[j].getyIncrement() * -1);

						int firstPersonnewxIncrement = (int) (Math.random() * 11 - 5);
						int firstPersonnewyIncrement = (int) (Math.random() * 11 - 5);
						int secondPersonnewxIncrement = (int) (Math.random() * 11 - 5);
						int secondPersonnewyIncrement = (int) (Math.random() * 11 - 5);

						// this will prevent Persons from "getting stuck" on the borders.
						PersonArray[i].setxIncrement(firstPersonnewxIncrement);
						PersonArray[i].setyIncrement(firstPersonnewyIncrement);
						PersonArray[j].setxIncrement(secondPersonnewxIncrement);
						PersonArray[j].setyIncrement(secondPersonnewyIncrement);

						if (PersonArray[i].getColor().equals(Color.RED)
								&& PersonArray[j].getColor().equals(Color.BLUE)) {
							random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
							if (random_int <= 80 && PersonArray[j].hasRecovered == false) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numNImmune++;
							} else if (random_int <= 40) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numNImmune++;
							}
							// change second Person to color of first Person
							// PersonArray[j].setColor(PersonArray[i].getColor());
						}
						if (PersonArray[i].getColor().equals(Color.RED)
								&& PersonArray[j].getColor().equals(Color.CYAN)) {
							random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
							if (random_int <= 60 && PersonArray[j].hasRecovered == false) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.isInfected = true;
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								numInfected++;
								numOneShot++;

							} else if (random_int <= 40) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numOneShot++;
							}
							// change second Person to color of first Person
							// PersonArray[j].setColor(PersonArray[i].getColor());
						}
						if (PersonArray[i].getColor().equals(Color.RED)
								&& PersonArray[j].getColor().equals(Color.YELLOW)) {
							random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
							if (random_int <= 30) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numTwoShot++;
							}
							// change second Person to color of first Person
							// PersonArray[j].setColor(PersonArray[i].getColor());
						}
						if (PersonArray[i].getColor().equals(Color.RED)
								&& PersonArray[j].getColor().equals(Color.MAGENTA)) {
							random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
							if (random_int <= 10) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numThreeShot++;
							}
							// change second Person to color of first Person
							// PersonArray[j].setColor(PersonArray[i].getColor());
						}
						if (PersonArray[i].getColor().equals(Color.RED)
								&& PersonArray[j].getColor().equals(Color.GREEN)) {
							random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
							if (random_int >= 90) {
								person = PersonArray[j];
								person.setColor(Color.RED);
								person.setInfectionTimer(infectionTimer = new Timer(recoveryTime, killPerson));
								person.isInfected = true;
								numInfected++;
								numImmune++;
							}
							// change second Person to color of first Person
							// PersonArray[j].setColor(PersonArray[i].getColor());
						}
					} // end if
				} // end inner for
			} // end outer loop

			// call repaint(), which in turn calls paintComponent()
			repaint();

		}// end method

	}// end inner class

	/*
	 * Function: calcPosition()
	 * Description: Calculates the position of the Person in the grid.
	 * Parameters: Person person - the Person whose position is to be calculated 
	 * Return: void
	 */
	 
	public void calcPosition(Person Person) {

		if (Person.hasDied)
			return;

		if (Person.getxCoord() >= WIDTH - Person.getDiameter()) {
			// we are at right side, so change xIncrement to a negative
			Person.setxIncrement(Person.getxIncrement() * -1);
		}
		if (Person.getxCoord() <= 0)
		{
			// if true, we're at left edge, flip the flag
			Person.setxIncrement(Person.getxIncrement() * -1);

		}
		if (Person.getyCoord() >= HEIGHT - Person.getDiameter()) {
			Person.setyIncrement(Person.getyIncrement() * -1);
		}
		if (Person.getyCoord() <= 0) {
			// if true, we're at left edge, flip the flag
			Person.setyIncrement(Person.getyIncrement() * -1);
			;
		}
		Person.setxCoord(Person.getxCoord() + Person.getxIncrement());
		Person.setyCoord(Person.getyCoord() + Person.getyIncrement());

	}// end calcPosition

}// end class