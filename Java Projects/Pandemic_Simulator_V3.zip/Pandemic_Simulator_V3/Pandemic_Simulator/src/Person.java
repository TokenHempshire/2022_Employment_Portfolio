

/**
 * Author: Kareem Idris, Student#: 0881393 Section:, Geraldine Lopez Student#: 0876012 Section: 2, Richard Gagne Student#: 0979551 Section: 4, Matt Daly Student#: 1022438 Section 4
 * Program: Person.java
 * Purpose: Creates the people objects.
 * Date: Aug 10, 2022
 */
import javax.swing.*;
import java.awt.*;

public class Person {
	enum ImmunityStatus {
		NONE,
		MILD,
		MODERATE,
		GOOD,
		NATURAL
	}

	public ImmunityStatus immunityStatus;

	boolean isAlive = true;
	boolean isInfected = false;
	boolean hasDied = false;
	boolean hasRecovered = false;
	private Timer infectionTimer;
	private int xCoord;
	private int yCoord;
	private int diameter;
	private Color color;
	private int xIncrement;
	private int yIncrement;
	private Person.ImmunityStatus status;

	/*
	 * Function: Person()
	 * Purpose: Constructor for the person class.
	 * Parameters: x - x coordinate of the person, y - y coordinate of the person, color - color of the person, immunityStatus - immunity status of the person
	 * Return: none
	 */
	 
	public Person(int x, int y, int diam, Color color, ImmunityStatus immunityStatus) {

		// assign parameters
		this.xCoord = x;
		this.yCoord = y;
		this.diameter = diam;
		this.color = color;
		boolean loopFlag = true;

		while (loopFlag) {
			this.xIncrement = (int) (Math.random() * 10 - 5);// note: this only goes to +4...adjust this to get +5
			this.yIncrement = (int) (Math.random() * 10 - 5);
			if (this.xIncrement == 0 && this.xIncrement == 0 && isAlive()) {
				// run it again
				this.xIncrement = (int) (Math.random() * 10 - 5);
				this.yIncrement = (int) (Math.random() * 10 - 5);
			} else {
				loopFlag = false;
			}
		} // end loop

	}// end constructor

	public Person() {
	}

	public Person(int diam, Color color, int widthValue, int heightValue, Person.ImmunityStatus immunityStatus) {
		this.diameter = diam;
		this.color = color;
		int randomX, randomY;
		boolean loopflag1 = true;

		
		while (loopflag1) {
			randomX = (int) (Math.random() * widthValue);
			if (randomX >= 0 && randomX <= widthValue - this.diameter) {
				// we have a valid x value, assign it to xCoord
				this.xCoord = randomX;
				// System.out.println("STUB:Valid random xCoord value of " + randomX);
				loopflag1 = false;

			}
		} // end while

		// reset flag1 to true to start second loop
		loopflag1 = true;
		while (loopflag1) {
			// repeat for yCoord
			randomY = (int) (Math.random() * heightValue);
			if (randomY >= 0 && randomY <= heightValue - this.diameter) {
				// we have a valid y value, assign it to yCoord
				this.yCoord = randomY;
				// System.out.println("STUB:Valid random yCoord value of " + randomY);
				loopflag1 = false;
			}
		} // end while
		boolean loopFlag = true;
		while (loopFlag) {
			this.xIncrement = (int) (Math.random() * 11 - 5);
			this.yIncrement = (int) (Math.random() * 11 - 5);
			if (this.xIncrement == 0 && this.xIncrement == 0) {
				// run it again
				this.xIncrement = (int) (Math.random() * 11 - 5);
				this.yIncrement = (int) (Math.random() * 11 - 5);

			} else {
				loopFlag = false;
			}
		} // end loop

	}// end random constructor

	public Person(boolean isInfected, boolean isAlive, boolean hasRecovered, boolean hasDied,
			ImmunityStatus immunityStatus, Timer infectionTimer) {
		super();
		this.isInfected = isInfected;
		this.isAlive = isAlive;
		this.hasRecovered = hasRecovered;
		this.hasDied = hasDied;
		this.immunityStatus = immunityStatus;
		this.infectionTimer = infectionTimer;
	}

	/*
	 * Function: GetColor()
	 * Purpose: Returns the color of the person.
	 * Parameters: none
	 * Return: Color - the color of the person
	 */

	public Color getColor() {
		return color;
	}

	/*
	 * Function: setColor()
	 * Purpose: Sets the color of the person.
	 * Parameters: Color - the color of the person
	 * Return: none
	 */
	 
	public void setColor(Color color) {
		this.color = color;
	}

	/*
	 * Function: getxCoord()
	 * Purpose: Returns the x coordinate of the person.
	 * Parameters: none
	 * Return: int - the x coordinate of the person
	 */
	 
	public int getxCoord() {
		return xCoord;
	}

	/*
	 * Function: getyCoord()
	 * Purpose: Returns the y coordinate of the person.
	 * Parameters: none
	 * Return: int - the y coordinate of the person
	 */
	 
	public int getyCoord() {
		return yCoord;
	}

	/*
	 * Function: getDiameter()
	 * Purpose: Returns the diameter of the person.
	 * Parameters: none
	 * Return: int - the diameter of the person
	 */
	public int getDiameter() {
		return diameter;
	}

	/*
	 * Function: setxCoord()
	 * Purpose: Sets the x coordinate of the person.
	 * Parameters: int - the x coordinate of the person
	 * Return: none
	 */
	 
	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}

	/*
	 * Function: setyCoord()
	 * Purpose: Sets the y coordinate of the person.
	 * Parameters: int - the y coordinate of the person
	 * Return: none
	 */

	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}

	/*
	 * Function: getxIncrement()
	 * Purpose: Returns the x increment of the person.
	 * Parameters: none
	 * Return: int - the x increment of the person
	 */
	 
	public int getxIncrement() {
		return xIncrement;
	}

	/*
	 * Funciton: setxIncrement()
	 * Purpose: Sets the x increment of the person.
	 * Parameters: int - the x increment of the person
	 * Return: none
	 */
	 
	public void setxIncrement(int xIncrement) {
		this.xIncrement = xIncrement;
	}

	/*
	 * Function: getyIncrement()
	 * Purpose: Returns the y increment of the person.
	 * Parameters: none
	 * Return: int - the y increment of the person
	 */

	public int getyIncrement() {
		return yIncrement;
	}

	/*
	 * Function: setyIncrement()
	 * Purpose: Sets the y increment of the person.
	 * Parameters: int - the y increment of the person
	 * Return: none
	 */
	
	public void setyIncrement(int yIncrement) {
		this.yIncrement = yIncrement;
	}

	/*
	 * Function: getInfecitonTimer()
	 * Purpose: Returns the infection timer of the person.
	 * Parameters: none
	 * Return: Timer - the infection timer of the person
	 */
	 
	public Timer getInfectionTimer() {
		return infectionTimer;
	}

	/*
	 * Function: setInfectionTimer()
	 * Purpose: Sets the infection timer of the person.
	 * Parameters: Timer - the infection timer of the person
	 * Return: none
	 */

	public void setInfectionTimer(Timer infectionTimer) {
		this.infectionTimer = infectionTimer;
		infectionTimer.start();
	}

	/*
	 * Function: setImmunityStatus()
	 * Purpose: Sets the immunity status of the person.
	 * Parameters: ImmunityStatus - the immunity status of the person
	 * Return: none
	 */
	 
	public void setImmunityStatus(Person.ImmunityStatus immunityStatus) {
		this.immunityStatus = immunityStatus;
	}

	/*
	 * Function: getImmunityStatus()
	 * Purpose: Returns the immunity status of the person.
	 * Parameters: none
	 * Return: ImmunityStatus - the immunity status of the person
	 */

	public Person.ImmunityStatus getImmunityStatus() {
		return immunityStatus;
	}

	/*
	 * Function isInfected()
	 * Purpose: Returns whether the person is infected.
	 * Parameters: none
	 * Return: boolean - whether the person is infected
	 */
	 
	public boolean isInfected() {
		return isInfected;
	}

	/*
	 * Function: setInfected()
	 * Purpose: Sets whether the person is infected.
	 * Parameters: boolean - whether the person is infected
	 * Return: none
	 */

	public void setInfected(boolean isInfected) {
		this.isInfected = isInfected;
	}

	/*
	 * Function: isAlive()
	 * Purpose: Returns whether the person is alive.
	 * Parameters: none
	 * Return: boolean - whether the person is alive
	 */

	public boolean isAlive() {
		return isAlive;
	}

	/*
	 * Function: setAlive()
	 * Purpose: Sets whether the person is alive.
	 * Parameters: boolean - whether the person is alive
	 * Return: none
	 */

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	/*
	 * Function: isRecovered()
	 * Purpose: Returns whether the person has recovered.
	 * Parameters: none
	 * Return: boolean - whether the person has recovered
	 */
	
	public boolean isRecovered() {
		return hasRecovered;
	}

	/*
	 * Function: setRecovered()
	 * Purpose: Sets whether the person has recovered.
	 * Parameters: boolean - whether the person has recovered
	 * Return: none
	 */

	public void setRecovered(boolean hasRecovered) {
		this.hasRecovered = hasRecovered;
	}

	/*
	 * Function: isDied()
	 * Purpose: Returns whether the person has died.
	 * Parameters: none
	 * Return: boolean - whether the person has died
	 */
	 
	public boolean isDied() {
		return hasDied;
	}

	/*
	 * Function: setDied()
	 * Purpose: Sets whether the person has died.
	 * Parameters: boolean - whether the person has died
	 * Return: none
	 */

	public void setDied(boolean hasDied) {
		this.hasDied = hasDied;
	}

	/*
	 * Function: getStatus()
	 * Purpose: Returns the status of the person.
	 * Parameters: none
	 * Return: Status - the status of the person
	 */

	public Person.ImmunityStatus getStatus() {
		return this.status;
	}

	/*
	 * Function: setAlive()
	 * Purpose: Sets wheter the person is alive.
	 * Parameters: Status - the status of the person
	 * Return: none
	 */
	 
	void setAlive() {
		isAlive = true;
	}

}
// end class