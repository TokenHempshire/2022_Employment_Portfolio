package com.example.richardgagne.rg_project1;

import java.util.Date;

public class Medicine {
    public int id_;
    public String sName_;
    public int sAmountTaken_;
    public String TimeTaken_;

    public Medicine(int id_, String sName_, int sAmountTaken_, String TimeTaken_) {
        this.id_ = id_;
        this.sName_ = sName_;
        this.sAmountTaken_ = sAmountTaken_;
        this.TimeTaken_ = TimeTaken_;
    }

    public int getId_() {
        return id_;
    }

    public void setId_(int id_) {
        this.id_ = id_;
    }

    public String getsName_() {
        return sName_;
    }

    public void setsName_(String sName_) {
        this.sName_ = sName_;
    }

    public int getsAmountTaken_() {
        return sAmountTaken_;
    }

    public void setsAmountTaken_(int sAmountTaken_) {
        this.sAmountTaken_ = sAmountTaken_;
    }

    public String getsTimeTaken_() {
        return TimeTaken_;
    }

    public void setsTimeTaken_(String TimeTaken_) {
        this.TimeTaken_ = TimeTaken_;
    }

    @Override
    public String toString() {
        return "Medicine{" +
                "id_=" + id_ +
                ", sName_='" + sName_ + '\'' +
                ", sAmountTaken_='" + sAmountTaken_ + '\'' +
                ", TimeTaken_='" + TimeTaken_ + '\'' +
                '}';
    }
}
