package com.example.richardgagne.rg_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    private EditText name, amount, dateTime;
    public Medicine newMedicineToAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        name = findViewById(R.id.editTextName);
        amount = findViewById(R.id.editTextAmount);
        dateTime = findViewById(R.id.editTextDateTime);
    }

    @Override //Probably will remove...
    protected void onPause() {

//        SharedPreferences settings = getSharedPreferences("dataInformation", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = settings.edit();
//        editor.putString("name", name.getText().toString());
//        editor.apply();
//        editor.putString("amount", amount.getText().toString());
//        editor.apply();
//        editor.putString("timeDate", dateTime.getText().toString());
//        editor.apply();
        //Log.i(TAG, "In the Pause");
        super.onPause();
    }

    //=========================================================================================\\
    // On return to the main menu, the information added here will be carried over to the main \\
    // where it will be added to the medicine list. As well as it will be shown at the bottom  \\
    // of the list of medicine.                                                                \\
    //=========================================================================================\\
    public void onReturnToMain(View view)
    {
        newMedicineToAdd.sName_ = name.getText().toString();
        String value = amount.getText().toString();
        newMedicineToAdd.sAmountTaken_ = Integer.parseInt(value);
        newMedicineToAdd.TimeTaken_ = dateTime.getText().toString();

        Intent newMedicineInformation = new Intent(this, MainActivity.class);
        newMedicineInformation.putExtra("new_name", newMedicineToAdd.sName_);
        newMedicineInformation.putExtra("new_amount", newMedicineToAdd.sAmountTaken_);
        newMedicineInformation.putExtra("new_datetime", newMedicineToAdd.TimeTaken_);

        finish();
        startActivity(newMedicineInformation);
    }
}