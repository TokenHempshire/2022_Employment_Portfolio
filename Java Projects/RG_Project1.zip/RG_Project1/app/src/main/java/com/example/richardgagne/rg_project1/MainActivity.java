package com.example.richardgagne.rg_project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.util.Log;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    final String TAG = "Logcat";

    ArrayList<Medicine> medicineArrayList;
    String textTitle = "Richards Project";
    String textContent = "Welcome";
    Intent getNewMedicine;
    String newMedicineName;
    String newMedicineAmount;
    String newMedicineDateTime;
    Medicine newMedicine;

    public static final int NOTIFICATION_ID = 1;
    public static final String CHANNEL_ID = "channel_01";
    public static final String CHANNEL_NAME = "INFO3136_Channel";

    private Button remove_Last_Btn, reset_Button, load_Previous_Button, add_Button;
    //private EditText name, amount, dateTime; // doesnt exist?

    private TextView textNameReport, textAmountReport, textTimeDateReport, textViewDisplay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        load_Previous_Button = findViewById(R.id.loadPreviousButton);
        remove_Last_Btn = findViewById(R.id.removeLast);
        reset_Button = findViewById(R.id.resetButton);
        add_Button = findViewById(R.id.addBtn);

        textViewDisplay = findViewById(R.id.textViewDisplay);
        textNameReport = findViewById(R.id.reportNameText);
        textAmountReport = findViewById(R.id.reportAmountText);
        textTimeDateReport = findViewById(R.id.reportTDText);

        try {
            getNewMedicine = getIntent();
            newMedicineName = getNewMedicine.getStringExtra("new_name");
            if (newMedicineName != null) {
                textNameReport.setText(newMedicineName);
                newMedicine.sName_ = newMedicineName;
            }


            newMedicineAmount = getNewMedicine.getStringExtra("new_amount");
            boolean _isNumber = false;
            if (newMedicineAmount != null) {
                textAmountReport.setText(newMedicineAmount);
                newMedicine.sAmountTaken_ = Integer.parseInt(newMedicineAmount);
            }


            newMedicineDateTime = getNewMedicine.getStringExtra("new_datetime");
            if (newMedicineDateTime != null) {
                textTimeDateReport.setText(newMedicineDateTime);
                newMedicine.TimeTaken_ = newMedicineDateTime;
            }
        }catch(NumberFormatException e)
        {
            textViewDisplay.setText("The Amount Is Not A Number");
        }catch (NullPointerException ne)
        {
            textViewDisplay.setText("One or More is Null");
        }



        medicineArrayList = new ArrayList<Medicine>();

        int count = 0;

        Medicine Lisdexamfetamine = new Medicine(count, "Lisdexamfetamine", 1, "2022-06-16");
        medicineArrayList.add(Lisdexamfetamine);

        Medicine Pantoprazole = new Medicine(count+1, "Pantoprazole", 1, "2022-06-16");
        medicineArrayList.add(Pantoprazole);

        Medicine Brodalumab = new Medicine(count+2, "Brodalumab", 1, "2022-06-16");
        medicineArrayList.add(Brodalumab);

        if(getNewMedicine!= null) {
            medicineArrayList.add(newMedicine);
        }

        createNotificationChannel();

        Log.i(TAG,"In the onCreate\nMedicine List Size: " + medicineArrayList.size());
    }

    //===================\\
    //   onButtonClick   \\
    //===================\\

    public void onButtonClick(View view){
        int index;

        switch (view.getId())
        {
            case R.id.loadPreviousButton: // load previous records
                textViewDisplay.setText("");
                try {
                    index = medicineArrayList.size() - 1;
                    textViewDisplay.setText(index);
                }catch(Exception ex){
                    textViewDisplay.setText("No Last Record To Preview");
                }
                break;
            case R.id.removeLast: // remove last record
                try {
                    index = medicineArrayList.size() - 1;
                    medicineArrayList.remove(index);
                }catch(Exception ex)
                {
                    textViewDisplay.setText("No Record To Remove");
                }
                break;
            case R.id.resetButton: // reset/remove all records
                try {
                    if(medicineArrayList != null) {
                        for (int i = 0; i < medicineArrayList.size(); i++) {
                            medicineArrayList.remove(i);
                        }
                    }
                }catch(Exception ex)
                {
                    textViewDisplay.setText("No Records To Remove");
                }
                break;
            case R.id.loadAll: // print out all the medicine
                try{
                textViewDisplay.setText("");
                String listOfMedicine = "";
                    if(medicineArrayList != null) {
                        for (int i = 0; i < medicineArrayList.size(); i++) {
                            listOfMedicine += medicineArrayList.indexOf(i) + "\n";
                        }
                    }
                textViewDisplay.setText(listOfMedicine);
                }catch(Exception ex)
                {
                    textViewDisplay.setText("No Medicine To Load");
                }
                break;
            default:
        }
    }

    //====================\\
    //   onButtonReport   \\
    //====================\\

    public void onButtonReport(View view)
    {
        Intent intent = new Intent(this, AddActivity.class);//<- The activity you want it to change to
        startActivity(intent);
        //intent.putExtra("name", name.getText().toString());
        //intent.putExtra("amount", amount.getText().toString());
        //intent.putExtra("dateTime", dateTime.getText().toString());
    }


    //=========================\\
    //   Create Notification   \\
    //=========================\\

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance);
            channel.setDescription("INFO 3136 Project Notification");
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    //======================\\
    //   sendNotification   \\
    //======================\\

    public void sendNotification(View view) {
        String drugToInspect = textNameReport.toString();
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.drugs.com/" + drugToInspect + ".html"));
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID);

        builder.setSmallIcon(R.drawable.small_icon); //<- small icon name inside the drawable
        builder.setContentIntent(pendingIntent);
        builder.setAutoCancel(true);

        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.large_icon)); //<- large icon name inside the drawable

        builder.setContentTitle(textTitle);
        builder.setContentText(textContent);
        builder.setSubText("");

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    //=============\\
    //   onStart   \\
    //=============\\

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "In the start");
    }

    //==============\\
    //   onResume   \\
    //==============\\

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences settings = getSharedPreferences("dataInformation", Context.MODE_PRIVATE);
 //       name.setText(settings.getString("name", ""));
 //       amount.setText(settings.getString("amount", ""));
  //      dateTime.setText(settings.getString("dateTime", ""));
        Log.i(TAG, "In the resume");
    }

    //=============\\
    //   onPause   \\
    //=============\\

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "In the Pause");
    }

    //===============\\
    //   onDestroy   \\
    //===============\\

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "In the Destroy");
    }
}