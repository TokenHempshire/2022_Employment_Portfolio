﻿using System;
using System.Collections.Immutable;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using System.Xml.XPath;
using Exception = System.Exception;


namespace RG_Global_Economics_Project
{
    class Program
    {
        public static Program? Program1 { get; } = new Program();
        // public static XPathDocument DocumentNavigator { get; } = new XPathDocument("global_economies.xml");
        public static string XpathExpression { get; } = "";
        public static string ReadFile { get; } = "global_economies.xml";
        
        public static XmlDocument _document { get; } = new XmlDocument();
        public static XPathNavigator? _navigator { get; } = _document.CreateNavigator();
        public static string _startdate = "1970", _enddate = "1973";
        public static string listed_dates = "";
        public static int number_of_years = Int32.Parse(_enddate) - Int32.Parse(_startdate);

        //===========\\
        //   Lists   \\
        //===========\\

        public static List<string?> region_list = new List<string?>();
        public static List<string?> inflation_cpi_list = new List<string?>();
        public static List<string?> inflation_gdp_list = new List<string?>();
        public static List<string?> real_interest_list = new List<string?>();
        public static List<string?> lending_interest_list = new List<string?>();
        public static List<string?> deposit_interest_list = new List<string?>();
        public static List<string?> unemployment_ntl_list = new List<string?>();
        public static List<string?> unemployment_ipo_list = new List<string?>();
        public static List<string?> region_cpi_list = new List<string?>();
        public static List<string?> region_gdp_list = new List<string?>();
        public static List<string?> region_real_interest_list = new List<string?>();
        public static List<string?> region_lending_interest_list = new List<string?>();
        public static List<string?> region_deposit_interest_list = new List<string?>();
        public static List<string?> region_unemployment_ntl_list = new List<string?>();
        public static List<string?> region_unemployment_ipo_list = new List<string?>();
        public static string region_name;

        //=================\\
        //   Expressions   \\
        //=================\\
        

        //===================\\
        //   Validate File   \\
        //===================\\

        public static bool ValidateFile(string fileroot)
        {
            XmlDocument test_document = new XmlDocument();
            Boolean isFile = true;
            try
            {
                test_document.Load(fileroot);
            }
            catch (XmlException ex)
            {
                Console.WriteLine(ex.Message);
                isFile = false;
            }

            return isFile;

        }//End of ValidateFile

        //==========\\
        //   Main   \\
        //==========\\
        
        static void Main(string[] args)
        {
            
             try
             {

                 if (ValidateFile(ReadFile) == true)
                 {
                     _document.Load(ReadFile);
                 }

                 //------------------------\\
                 //   Gather Region List   \\
                 //------------------------\\

                 string region_list_expression = $"//global_economies//region/@rname";
                 XPathNodeIterator _region_iterator = _navigator.Select(region_list_expression);
                 while (_region_iterator.MoveNext())
                 {
                     region_list.Add(_region_iterator.Current.Value);
                 }
                 

                MainMenu();
             }
             catch (XmlException ex)
             {
                Console.WriteLine(ex.Message);
             }
             catch (XPathException ex)
             {
                 Console.WriteLine(ex.Message);
             }
             catch (Exception ex)
             {
                 Console.WriteLine(ex.Message + "\n" + ex.InnerException + "\n" + ex.StackTrace + "\n" + ex.Source + "\n" + ex.Data + "\n" + ex.TargetSite);
             }
        }//End of Main

        static void MainMenu()
        {
            
            //var program = new Program();
            bool isMenu = true;
            do
            {
                Console.WriteLine("World Economic Data");
                Console.WriteLine("===================\n\n");
                Console.WriteLine("'Y' to adjust the range of years (currently 2017 to 2021)");
                Console.WriteLine("'R' to print a regional summary");
                Console.WriteLine("'M' to print a specific metric for all regions");
                Console.WriteLine("'X' to exit the program");
                Console.Write("Your Selection: ");
                string? userInput = Console.ReadLine().ToUpper();
                switch (userInput)
                {
                    case "Y":
                        RangeOfYears();
                        isMenu = false;
                        break;
                    case "R":
                        PrintRegionalSummary();
                        isMenu = false;
                        break;
                    case "M":
                        PrintSpecificMetricForAllRegions();
                        isMenu = false;
                        break;
                    case "X":
                        Console.WriteLine("All done!");
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine();
                        break;
                }
            } while (isMenu);

        }

        //====================\\
        //   Range Of Years   \\
        //====================\\

        public static void RangeOfYears()
        {
            //var program = new Program();
            int starting_year = 1970;
            int ending_year = 2021;
            Boolean isStartingYear = false;
            Boolean isEndingYear = false;
            try
            {
                do
                {
                    if (isStartingYear == false)
                    {
                        Console.Write("Starting year (1970 to 2017): ");
                        starting_year = Int32.Parse(Console.ReadLine());
                        Console.WriteLine();
                        if (CheckStartDate(starting_year) == true)
                        {
                            isStartingYear = true;
                        }

                        ;
                    }
                } while (!isStartingYear);

                Console.WriteLine("\n");

                do
                {
                    if (isEndingYear == false)
                    {
                        Console.Write("Ending year (1973 to 2021): ");
                        ending_year = Int32.Parse(Console.ReadLine());
                        Console.WriteLine();
                        if (CheckEndDate(ending_year, starting_year) == true)
                        {
                            isEndingYear = true;
                        }

                    }
                } while (!isEndingYear);

                if (isStartingYear == true && isEndingYear == true)
                {
                    _startdate = starting_year.ToString();
                    _enddate = ending_year.ToString();
                    number_of_years = (Int32.Parse(_enddate) - Int32.Parse(_startdate));
                    MainMenu();
                }
                else if(isStartingYear == false && isEndingYear == false || isStartingYear == false && isEndingYear == true || isStartingYear == true && isEndingYear == false)
                {
                    Console.WriteLine("Error: Start Date or End Date is wrong. Please make sure to stay within parameters.");
                    RangeOfYears();
                }
                else
                {
                    
                    MainMenu();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.Source + "\n" + ex.InnerException + "\n" + ex.HelpLink + "\n" + ex.StackTrace + "\n" + ex.TargetSite);
                
            }
            
        }

        //======================\\
        //   Check Start Date   \\
        //======================\\

        public static bool CheckStartDate(int startdate)
        {
            Boolean date = false;
            if (startdate < 1970)
            {
                // Print Error, Starting year less than 1970
                Console.WriteLine("Error: Your start date can't be less than 1970.");
            }
            else if (startdate > 2021)
            {
                // Print Error, Starting year is over 2021
                Console.WriteLine("Error: Your start date can't be over 2021.");
            }
            else
            {
                date = true;
            }
            return date;
        }

        //====================\\
        //   Check End Date   \\
        //====================\\

        public static bool CheckEndDate(int enddate, int startdate)
        {
            Boolean date = false;
            if (enddate < startdate)
            {
                // Print Error, Ending Year is less than Starting Year
                Console.WriteLine($"Error: Ending year must be an integer between {startdate} and {startdate+4}.");
            }
            else if (enddate > 2021)
            {
                // Print Error, Ending Year is more than 2021
                Console.WriteLine("Error: Ending year must be less than 2021.");
            }
            else if (enddate > (startdate + 5))
            {
                // Print Error, Ending Year is more than 5 + Starting Year
                Console.WriteLine($"Error: Ending year is more than 5 years from your starting date ({startdate}).");
            }
            else
            {
                date = true;
            }
            return date;
        }

        //============================\\
        //   Print Regional Summary   \\
        //============================\\

        public static void PrintRegionalSummary()
        {
            Console.WriteLine("Select a region by number as shown below...\n");

            for (int i = 0; i < region_list.Count; i++)
            {
                Console.WriteLine(i+1 + ". " + region_list[i]);
            }

            Console.Write("\nEnter a region #: ");
            int userInput = Int32.Parse(Console.ReadLine());
            region_name = region_list[userInput-1];
            
            //-----------------\\
            //   Print Title   \\
            //-----------------\\

            string title = $"\nEconomic Information for {region_name}";
            Console.WriteLine(title);
            for(int j = 0; j < title.Length; j++)
                Console.Write("-");
            Console.WriteLine();
            
            //---------------------\\
            //   economic Metric   \\
            //---------------------\\
            int start_date = Int32.Parse(_startdate);
            Console.Write("\t\t\tEconomic Metric\t");
            for (int i = 0; i <= number_of_years; i++)
            {
                Console.Write("{0,11}", start_date);
                start_date++;
            }
            Console.WriteLine();



            //-------------------\\
            //   Inflation CPI   \\
            //-------------------\\
            try
            {
                string inflation_CPI_Expression = $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/inflation/@consumer_prices_percent";
                XPathNodeIterator _cpi_Iterator = _navigator.Select(inflation_CPI_Expression);
                string inflation_cpi = "";

                while (_cpi_Iterator.MoveNext())
                {
                    inflation_cpi_list.Add(_cpi_Iterator.Current.Value);
                }
                
                Console.Write("\t\t\t{0}\t", "Inflation CPI");
                for(int i = 0; i < inflation_cpi_list.Count; i++)
                    Console.Write("{0,11}", inflation_cpi_list[i]);
                if (inflation_cpi_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,11}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            



            //-------------------\\
            //   Inflation GDP   \\
            //-------------------\\
            try
            {
                string inflation_GDP_Expression = $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/inflation/@gdp_deflator_percent";
                XPathNodeIterator _gdp_iterator = _navigator.Select(inflation_GDP_Expression);
                string inflation_gdp = "";

                while (_gdp_iterator.MoveNext())
                {
                    inflation_gdp_list.Add(_gdp_iterator.Current.Value);
                }
                
                Console.Write("\t\t\t{0}\t", "Inflation GDP");
                for (int i = 0; i < inflation_gdp_list.Count; i++)
                        Console.Write("{0,11}", inflation_gdp_list[i]);
                if(inflation_gdp_list.Count == 0)
                    for(int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,11}", "-");
                Console.WriteLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            



            //---------------------\\
            //   Real Interest %   \\
            //---------------------\\
            try
            {
                
                string real_Interest_Expression =
                    $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@real";
                XPathNodeIterator _real_iterator = _navigator.Select(real_Interest_Expression);
                string interest_real = "";

                while (_real_iterator.MoveNext())
                {
                    real_interest_list.Add(_real_iterator.Current.Value);
                }
                
                Console.Write("\t\t\t{0}\t", "Real Interest %");
                for (int i = 0; i < real_interest_list.Count; i++)
                    Console.Write("{0,11}", real_interest_list[i]);
                if (real_interest_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,11}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //------------------------\\
            //   Lending Interest %   \\
            //------------------------\\
            try
            {
                string lending_Interest_Expression =
                    $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@lending";
                XPathNodeIterator _lending_iterator = _navigator.Select(lending_Interest_Expression);
                string interest_lending = "";

                while (_lending_iterator.MoveNext())
                {
                    lending_interest_list.Add(_lending_iterator.Current.Value);
                }
                
                Console.Write("\t\t\t{0}\t", "Lending Interest %");
                for (int i = 0; i < lending_interest_list.Count; i++)
                    Console.Write("{0,-11}", lending_interest_list[i]);
                if (lending_interest_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,-12}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //-------------------------\\
            //   Desposit Interest %   \\
            //-------------------------\\
            try
            {
                string deposit_Interest_Expression =
                    $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@deposit";
                XPathNodeIterator _deposit_iterator = _navigator.Select(deposit_Interest_Expression);
                string interest_deposit = "";

                while (_deposit_iterator.MoveNext())
                {
                    deposit_interest_list.Add(_deposit_iterator.Current.Value);
                }

               
                Console.Write("\t\t\t{0}\t", "Deposit Interest %");
                for (int i = 0; i < deposit_interest_list.Count; i++)
                    Console.Write("{0,-11}", deposit_interest_list[i]);
                if (deposit_interest_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,-12}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //------------------------\\
            //   Unemployment NTL %   \\
            //------------------------\\
            try
            {
                string unemployment_NTL_Expression =
                    $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/unemployment/@national_estimate";
                XPathNodeIterator _national_iterator = _navigator.Select(unemployment_NTL_Expression);
                string unemployment_national = "";

                while (_national_iterator.MoveNext())
                {
                    unemployment_ntl_list.Add(_national_iterator.Current.Value);
                }

               
                Console.Write("\t\t\t{0}\t", "Unemployment NTL %");
                for (int i = 0; i < unemployment_ntl_list.Count; i++)
                    Console.Write("{0,-11}", unemployment_ntl_list[i]);
                if (unemployment_ntl_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,-12}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            //-------------------------\\
            //   Unemployement IPO %   \\
            //-------------------------\\
            try
            {
                string unemployment_IPO_Expression =
                    $"//region[@rname=\"{region_name}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/unemployment/@modeled_ILO_estimate";
                XPathNodeIterator _ipo_iterator = _navigator.Select(unemployment_IPO_Expression);
                string unemployment_ipo = "";

                while (_ipo_iterator.MoveNext())
                {
                    unemployment_ipo_list.Add(_ipo_iterator.Current.Value);
                }

                Console.Write("\t\t\t{0}\t", "Unemployement IPO %");
                for (int i = 0; i < unemployment_ipo_list.Count; i++)
                    Console.Write("{0,-11}", unemployment_ipo_list[i]);
                if (unemployment_ipo_list.Count == 0)
                    for (int i = 0; i <= number_of_years; i++)
                        Console.Write("{0,-12}", "-");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();
            MainMenu();
        }

        //===========================================\\
        //   Print Specific Metric For All Regions   \\
        //===========================================\\

        public static void PrintSpecificMetricForAllRegions()
        {
            int start_date = Int32.Parse(_startdate);
            for (int i = 0; i <= number_of_years; i++)
            {
                listed_dates += start_date + "\t";
                start_date++;
            }
            Console.WriteLine("Select a metric by number as shown below...");
            Console.WriteLine("\t1. Inflation CPI");
            Console.WriteLine("\t2. Inflation GDP");
            Console.WriteLine("\t3. Real interest %");
            Console.WriteLine("\t4. Lending Interest %");
            Console.WriteLine("\t5. Deposit Interest %");
            Console.WriteLine("\t6. Unemployment NTL %");
            Console.WriteLine("\t7. Unemployment IPO %\n\n");
            Console.Write("Enter a metric #: ");
            int userInput = Int32.Parse(Console.ReadLine());
            Console.WriteLine("");
            switch (userInput)
            {
                case 1:
                    GetInflationCPI();
                    MainMenu();
                    break;
                case 2:
                    GetInflationGDP();
                    MainMenu();
                    break;
                case 3:
                    GetRealInterest();
                    MainMenu();
                    break;
                case 4:
                    GetLendingInterest();
                    MainMenu();
                    break;
                case 5:
                    GetDepositInterest();
                    MainMenu();
                    break;
                case 6:
                    GetUnemploymentNTL();
                    MainMenu();
                    break;
                case 7:
                    GetUnemploymentIPO();
                    MainMenu();
                    break;
                default:
                    Console.WriteLine();
                    MainMenu();
                    break;
            }

            //=========================================\\
            //  #1 Get Inflation CPI For All Regions   \\
            //=========================================\\

            static void GetInflationCPI()
            {
                Console.WriteLine("Inflation CPI By Region");
                Console.WriteLine("------------------------\n");
                try
                {
                    string cpi_selection = "";
                    string cpi_Expression = "";
                    XPathNodeIterator _cpi_iterator;
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();


                    for (int i = 0; i < region_list.Count; i++)
                    {
                        cpi_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/inflation/@consumer_prices_percent";
                        _cpi_iterator = _navigator.Select(cpi_Expression);
                        
                        while (_cpi_iterator.MoveNext())
                        {
                            region_cpi_list.Add(_cpi_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }

                        for (int j = 0; j < region_cpi_list.Count; j++)
                            Console.Write("{0,11}", region_cpi_list[j]);
                        if (region_cpi_list.Count == 0)
                                 for (int k = 0; k <= number_of_years; k++)
                                     Console.Write("{0,-11}", "-");
                            Console.WriteLine();
                        
                        region_cpi_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //==========================================\\
            //   #2 Get Inflation GDP For All Regions   \\
            //==========================================\\

            static void GetInflationGDP()
            {
                Console.WriteLine("Inflation GDP By Region");
                Console.WriteLine("------------------------\n");
                try
                {
                    string gdp_selection = "";
                    string gdp_Expression;
                    XPathNodeIterator _gdp_iterator;
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        
                        gdp_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/inflation/@gdp_deflator_percent";
                        _gdp_iterator = _navigator.Select(gdp_Expression);

                        while (_gdp_iterator.MoveNext())
                        {
                            region_gdp_list.Add(_gdp_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }


                        for (int j = 0; j < region_gdp_list.Count; j++)
                            Console.Write("{0,11}", region_gdp_list[j]);
                        if (region_gdp_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_gdp_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //=====================================================\\
            //   #3 Get Real Interest Percentage For All Regions   \\
            //=====================================================\\

            static void GetRealInterest()
            {
                Console.WriteLine("Real Interest % By Region");
                Console.WriteLine("-------------------------\n");
                try
                {
                    string real_selection = "";
                    string real_Expression;
                    XPathNodeIterator _real_iterator;
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        
                        real_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@real";
                        _real_iterator = _navigator.Select(real_Expression);

                        while (_real_iterator.MoveNext())
                        {
                            region_real_interest_list.Add(_real_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }


                        for (int j = 0; j < region_real_interest_list.Count; j++)
                            Console.Write("{0,11}", region_real_interest_list[j]);
                        if (region_real_interest_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_real_interest_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //=======================================================\\
            //   #4 Get Lending Interest Percentage For All Region   \\
            //=======================================================\\

            static void GetLendingInterest()
            {
                Console.WriteLine("Lending Interest % By Region");
                Console.WriteLine("----------------------------\n");
                try
                {
                    string lending_selection = "";
                    string lending_Expression;
                    XPathNodeIterator _lending_iterator;
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        
                        lending_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@lending";
                        _lending_iterator = _navigator.Select(lending_Expression);

                        while (_lending_iterator.MoveNext())
                        {
                            region_lending_interest_list.Add(_lending_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }

                        for (int j = 0; j < region_lending_interest_list.Count; j++)
                            Console.Write("{0,11}", region_lending_interest_list[j]);
                        if (region_lending_interest_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_lending_interest_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //========================================================\\
            //   #5 Get Deposit Interest Percentage For All Regions   \\
            //========================================================\\

            static void GetDepositInterest()
            {
                Console.WriteLine("Deposit Interest % By Region");
                Console.WriteLine("----------------------------\n");
                try
                {
                    string deposit_selection = "";
                    string deposit_Expression;
                    XPathNodeIterator _deposit_iterator;
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        
                        deposit_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/interest_rates/@deposit";
                        _deposit_iterator = _navigator.Select(deposit_Expression);
                        while (_deposit_iterator.MoveNext())
                        {
                            region_deposit_interest_list.Add(_deposit_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }

                        for (int j = 0; j < region_deposit_interest_list.Count; j++)
                            Console.Write("{0,11}", region_deposit_interest_list[j]);
                        if (region_deposit_interest_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_deposit_interest_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine(ex.Message);
                }
            }

            //========================================================\\
            //   #6 Get Unemployment NTL Percentage For All Regions   \\
            //========================================================\\

            static void GetUnemploymentNTL()
            {
                Console.WriteLine("Unemployment NTL % By Region");
                Console.WriteLine("----------------------------\n");
                try
                {
                    string ntl_selection = "";
                    string ntl_Expression;
                    XPathNodeIterator _national_iterator;
                    string unemployment_national = "";
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        
                        ntl_Expression = $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/unemployment/@national_estimate";
                        _national_iterator = _navigator.Select(ntl_Expression);
                        while (_national_iterator.MoveNext())
                        {
                            region_unemployment_ntl_list.Add(_national_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }

                        for (int j = 0; j < region_unemployment_ntl_list.Count; j++)
                            Console.Write("{0,11}", region_unemployment_ntl_list[j]);
                        if (region_unemployment_ntl_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_unemployment_ntl_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //=======================================================\\
            //  #7 Get Unemployment Percentage IPO For All Regions   \\
            //=======================================================\\

            static void GetUnemploymentIPO()
            {
                Console.WriteLine("Unemployment IPO % By Region");
                Console.WriteLine("----------------------------\n");
                try
                {
                    string ipo_selection = "";
                    string ipo_Expression;
                    XPathNodeIterator _ipo_iterator;
                    string unemployment_ipo = "";
                    int start_date = Int32.Parse(_startdate);
                    Console.Write("\tRegion\t\t\t\t\t\t\t");
                    for (int i = 0; i <= number_of_years; i++)
                    {
                        Console.Write("{0,11}", start_date);
                        start_date++;
                    }
                    Console.WriteLine();

                    for (int i = 0; i < region_list.Count; i++)
                    {
                        ipo_selection += $"\t\t\t{region_list[i]}\t";
                        ipo_Expression =
                            $"//region[@rname=\"{region_list[i]}\"]/year[(@yid>={_startdate}) and (@yid<={_enddate})]/unemployment/@modeled_ILO_estimate";
                        _ipo_iterator = _navigator.Select(ipo_Expression);
                        while (_ipo_iterator.MoveNext())
                        {
                            region_unemployment_ipo_list.Add(_ipo_iterator.Current.Value);
                        }

                        if (region_list[i].Length > 42)
                        {
                            Console.Write($"\t{region_list[i]} ");
                        }
                        else if (region_list[i].Length >= 34)
                        {
                            Console.Write($"\t{region_list[i]}\t");
                        }
                        else if (region_list[i].Length >= 30)
                        {
                            Console.Write($"\t{region_list[i]}\t\t");
                        }
                        else if (region_list[i].Length >= 25)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t");
                        }
                        else if (region_list[i].Length >= 22)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 16)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t");
                        }
                        else if (region_list[i].Length > 7)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t");
                        }
                        else if (region_list[i].Length >= 4)
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t");
                        }
                        else
                        {
                            Console.Write($"\t{region_list[i]}\t\t\t\t\t\t\t\t");
                        }

                        for (int j = 0; j < region_unemployment_ipo_list.Count; j++)
                            Console.Write("{0,11}", region_unemployment_ipo_list[j]);
                        if (region_unemployment_ipo_list.Count == 0)
                            for (int k = 0; k <= number_of_years; k++)
                                Console.Write("{0,11}", "-");
                        Console.WriteLine();

                        region_unemployment_ipo_list.Clear();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

    }
}