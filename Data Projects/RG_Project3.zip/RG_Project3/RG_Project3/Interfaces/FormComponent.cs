﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Classes;

namespace RG_Project3.Interfaces
{
    public interface FormComponent
    {

        //==============\\
        //   Get Name   \\
        //==============\\

        string getName();

        //===============\\
        //   Get Value   \\
        //===============\\

        string getValue();

        //===============\\
        //   Set Value   \\
        //===============\\

        bool setValue(string value);

        //=============\\
        //   isValid   \\
        //=============\\

        bool isValid();

    }
}
