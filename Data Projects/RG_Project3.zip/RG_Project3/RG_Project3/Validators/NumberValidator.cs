﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Interfaces;

namespace RG_Project3.Validators
{
    internal class NumberValidator : Validator
    {
        public NumberValidator(FormComponent validNumber) : base(validNumber)
        {
        }

        //==============\\
        //   Get Name   \\
        //==============\\

        public override string getName()
        {
            return formComponent.getName();
        }

        //===============\\
        //   Get Value   \\
        //===============\\

        public override string getValue()
        {
            return formComponent.getValue();
        }

        //===============\\
        //   Set Value   \\
        //===============\\

        public override bool setValue(string value)
        {
            return formComponent.setValue(value);
        }
        
        //=============\\
        //   isValid   \\
        //=============\\

        public override bool isValid()
        {
            int properNum;
            if (Int32.TryParse(formComponent.getValue(), out properNum))
            {
                return formComponent.isValid();
            }

            return false;
        }
    }
}
