﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Interfaces;
using RG_Project3.Validators;

namespace RG_Project3.Validators__Decorators_
{
    internal class MinLengthValidator : Validator
    {
        private int validLength;

        //================================\\
        //   Minimum Length Constructor   \\
        //================================\\

        public MinLengthValidator(FormComponent validMinimumLength, int length) : base(validMinimumLength)
        {
            this.validLength = length;
        }

        //==============\\
        //   Get Name   \\
        //==============\\

        public override string getName()
        {
            return formComponent.getName();
        }

        //===============\\
        //   Get Value   \\
        //===============\\

        public override string getValue()
        {
            return formComponent.getValue();
        }

        //===============\\
        //   Set Value   \\
        //===============\\

        public override bool setValue(string value)
        {
           return formComponent.setValue(value);
        }

        //=============\\
        //   isValid   \\
        //=============\\

        public override bool isValid()
        {
            if (formComponent.getValue().Length >= validLength)
            {
                return formComponent.isValid();
            }

            return false;
        }

    }
}
