﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Interfaces;

namespace RG_Project3.Validators
{
    public abstract class Validator : FormComponent //Decorator Class
    {
        protected FormComponent formComponent;

        public Validator(FormComponent formComponent)
        {
            this.formComponent = formComponent;
        }

        public abstract string getName();
        public abstract bool isValid();
        public abstract bool setValue(string value);
        public abstract string getValue();

    }
}
