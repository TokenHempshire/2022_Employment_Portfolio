﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Interfaces;

namespace RG_Project3.Classes
{
    public class Form // Mediator for FormComponent
    {
        List<FormComponent> components = new List<FormComponent>();

        //===================\\
        //   Add Component   \\
        //===================\\

        public void AddComponent(FormComponent formComponent)
        {
            components.Add(formComponent);
        }

        //===================\\
        //   Get Component   \\
        //===================\\

        public List<FormComponent> getComponent()
        {
            return components;
        }
    }
} 


