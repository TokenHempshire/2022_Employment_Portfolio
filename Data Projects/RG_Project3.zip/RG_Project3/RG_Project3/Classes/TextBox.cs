﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Interfaces;

namespace RG_Project3.Classes
{
    public class TextBox : FormComponent
    {
        private string value;
        private string name;

        //=============\\
        //   TextBox   \\
        //=============\\

        public TextBox(string name)
        {
            this.name = name;
        }

        //==================\\
        //   Get/Set Name   \\
        //==================\\

        public string getName()
        {
            return this.name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        //===================\\
        //   Get/Set Value   \\
        //===================\\
        public bool setValue(String value)
        {
            this.value = value;
            return true;
        }

        public string getValue()
        {
            return this.value;
        }

        //=============\\
        //   isValid   \\
        //=============\\

        public bool isValid()
        {
            return true;
        }
    }
}
