﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Classes;
using RG_Project3.Interfaces;
using RG_Project3.Validators;
using RG_Project3.States;

namespace RG_Project3.States
{
    public class Done : States
    {
        public Done(StateContext context) : base(context) { }

        //=========\\
        //   Run   \\
        //=========\\

        public override void Run()
        {
            Console.WriteLine("\nYou're done! To confirm, here's what you wrote: ");
            StateContext print = this._stateContext;
            Form form = print.getForm();
            List<FormComponent> printList = form.getComponent();
            for (int i = 0; i < printList.Count; i++)
            {
               Console.WriteLine(printList[i].getName() + " " + printList[i].getValue());
            }
        }
    }
}
