﻿using RG_Project3.Classes;
using RG_Project3.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RG_Project3.States
{
    public class StateContext   //FormInput
    {
        private States state;
        private Form form;

        //===============================\\
        //   State Context Constructor   \\
        //===============================\\

        public StateContext(Form form)
        {
            this.form = form;
        }

        
        //==================\\
        //   State Change   \\
        //==================\\

        public void stateChange(States state)
        {
            this.state = state;
            state.Run();
        }

        //---------\\
        //   Run   \\
        //---------\\

        public void Run()
        {
            this.state = new InputState(this);
            state.Run();
        }

        //==============\\
        //   Get Form   \\
        //==============\\

        public Form getForm()
        {
            return form;
        }
    }
    
}