﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RG_Project3.Classes;
using RG_Project3.Interfaces;
using RG_Project3.Validators;
using RG_Project3.Validators__Decorators_;
using RG_Project3.States;

namespace RG_Project3.States
{
    internal class MainMenu : States
    {
        public MainMenu(StateContext stateContext) : base(stateContext)
        {
        }

        // Program.StateContext context;
        //
        // public MainMenu(Program.StateContext context)
        // {
        //     this.context = context;
        // }

        string input = "";
        bool isValid = true;
        Form form = new Form();
        StateContext context;

        public void Run()
        {
            //Create the menu list
            

            int selectedValue = 0;
            do
            {
                input = Console.ReadLine();
                selectedValue = int.Parse(input);

                if (selectedValue < 1 || selectedValue > 2)
                {
                    isValid = false;
                    Console.WriteLine("Invalid Input!");
                }
            } while (!isValid);

            form.AddComponent(
                new MinLengthValidator(
                    new TextBox("Username"), 6
                )
            );
            form.AddComponent(
                new CharacterValidator(
                    new CharacterValidator(
                        new TextBox("Email"), "@"
                    ), "."
                )
            );
            form.AddComponent(
                new MinLengthValidator(
                    new TextBox("Real Name"), 2
                )
            );

            FormComponent password = new CharacterValidator(
                new MinLengthValidator(
                    new TextBox("Password"), 8
                ), "!"
            );
            form.AddComponent(password);

            form.AddComponent(
                new ValueMatchValidator(
                    new TextBox("Confirm Password"), password
                )
            );
            form.AddComponent(
                new NumberValidator(
                    new TextBox("Age")
                )
            );
            // if (selectedValue == 1)
            // {
            //     context.SetState(new EnterData(context, new Form()));
            // }
            // else if (selectedValue == 2)
            // {
            //     Environment.Exit(0);
            // }
        }
    }
}
