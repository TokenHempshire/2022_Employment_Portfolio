﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using RG_Project3.Classes;
using RG_Project3.Interfaces;

namespace RG_Project3.States
{
    public class InputState : States
    {
        public InputState(StateContext formInput) : base(formInput) { }

        //=========\\
        //   Run   \\
        //=========\\

        public override void Run()
        {
            StateContext userInput = this._stateContext;
            Console.WriteLine("Welcome to the Form.\n");
            Form userForm = userInput.getForm();
            List<FormComponent> newList = userForm.getComponent();

            //===============\\
            //   User Name   \\
            //===============\\

            Console.WriteLine(newList[0].getName());
            //Console.Write("Username: \n> ");
            string userName = Console.ReadLine();
            newList[0].setValue(userName);
            if(!newList[0].isValid())
            {
                while(!newList[0].isValid())
                {
                    Console.WriteLine("Invalid entry, try again. User name should be at least 6 characters.");
                    Console.WriteLine(newList[0].getName());
                    userName = Console.ReadLine();
                    newList[0].setValue(userName);
                }
            
            }

            //================\\
            //   User Email   \\
            //================\\

            Console.WriteLine(newList[1].getName());
            //Console.Write("Email: \n> ");
            string userEmail = Console.ReadLine();
            newList[1].setValue(userEmail);
            if(!newList[1].isValid())
            {
                while(!newList[1].isValid())
                {
                    Console.WriteLine("Invalid entry, try again. Must include '@' and '.'");
                    Console.WriteLine(newList[1].getName());
                    userEmail = Console.ReadLine();
                    newList[1].setValue(userEmail);
                }
            
            }

            //====================\\
            //   User Real Name   \\
            //====================\\

            Console.WriteLine(newList[2].getName());
            //Console.Write("Realname: \n> ");
            string userRealName = Console.ReadLine();
             newList[2].setValue(userRealName);
            if(!newList[2].isValid())
            {
                while(!newList[2].isValid())
                {
                    Console.WriteLine("Invalid entry, try again. Minimum length is 2.");
                    Console.WriteLine(newList[2].getName());
                    userRealName = Console.ReadLine();
                    newList[2].setValue(userRealName);
                }
            
            }

            //===================\\
            //   User Password   \\
            //===================\\

            Console.WriteLine(newList[3].getName());
            //Console.Write("Password: \n> ");
            string userPassword = Console.ReadLine();
             newList[3].setValue(userPassword);
            if(!newList[3].isValid())
            {
                while(!newList[3].isValid())
                {
                    Console.WriteLine("Invalid entry, please try again. The password should include a symbol '!' and at least 8 characters.");
                    Console.WriteLine(newList[3].getName());
                    userPassword = Console.ReadLine();
                    newList[3].setValue(userPassword);
                }
            
            }

            //======================\\
            //   Confirm Password   \\
            //======================\\

            Console.WriteLine(newList[4].getName());
            //Console.Write("Confirm Password: \n> ");
            string confirmPassword = Console.ReadLine();
            newList[4].setValue(confirmPassword);
            if(!newList[4].isValid())
            {
                while(!newList[4].isValid())
                {
                    Console.WriteLine("Invalid entry, try again. This password doesn't match and should be the exactly the same.");
                    Console.WriteLine(newList[4].getName());
                    confirmPassword = Console.ReadLine();
                    newList[4].setValue(confirmPassword);
                }
            
            }

            //=========\\
            //   Age   \\
            //=========\\

            Console.WriteLine(newList[5].getName());
            //Console.Write("Age: \n> ");
            string userAge = Console.ReadLine();
             newList[5].setValue(userAge);
            if(!newList[5].isValid())
            {
                while(!newList[5].isValid())
                {
                    Console.WriteLine("Invalid entry, try again. The age should be a number.");
                    Console.WriteLine(newList[5].getName());
                    userAge = Console.ReadLine();
                    newList[5].setValue(userAge);
                }
            
            }
            
             //====================\\
             //   Completed Form   \\
             //====================\\
            
            Console.WriteLine("Type Done to proceed and print or type Exit to quit: ");
            string userSelection = Console.ReadLine().ToLower();
            switch(userSelection)
            {
             case "done":
                userInput.stateChange(new Done(userInput));
                break;
             case "exit":
                System.Environment.Exit(1);
                break;
             default:
                Console.WriteLine("Choose either Done or Exit");
                break;
            }
        }

    }
}
